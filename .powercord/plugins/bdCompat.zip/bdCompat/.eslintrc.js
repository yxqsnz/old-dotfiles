module.exports = {
  extends: ['eslint:recommended', 'intrnl'],
  env: { node: true },
}
