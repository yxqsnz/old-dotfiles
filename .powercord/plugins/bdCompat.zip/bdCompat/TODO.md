# To do

- [x] Revisit the idea of replacing the require function to allow directly requiring the plugin files without creating temporary files
- [ ] Hot reloading of plugins
  - Should already be possible, just needs a function that unloads and loads, and a watcher.
